#pragma once
class Deer;
class Animal
{
protected :int age;
protected :int  weight;
public:
	char name[100];
	void write_file(Animal& obj);
	void read_file(Animal* obj, int n);
	void print_file(const Animal *obj, int n);
	Animal(const Animal &obj);
	Animal();
	~Animal();
};
class Mammals : public Animal
{
public:
	Mammals();
	~Mammals();
private:
	using Animal::age;
	char color[100];
};

class Artiodactyls:  public Mammals
{
public:
	Artiodactyls();
	~Artiodactyls();
	void getData(char*);
	void print_file();
	void getData();
private:
	char horns[100];
	char pet[100];
	friend void getData(char *, Artiodactyls&);
	friend void getData(Artiodactyls&);
	friend Deer;
};

class Dog: public Mammals
{

public:
	Dog();
	~Dog();

private:
	char breed[100];
};

class Deer :  public Artiodactyls
{
protected: char sex[10];
public:
	void getChangeData(Artiodactyls);
};

class  ArtDog: public Artiodactyls, public Dog
{
private:
	 char exist[100];
public:
	ArtDog(char ex[100]);
	void print();
};

 

//������ 
class  plazun: public Animal
{
private:
	int X, Y;
public:
	int povz();
};
class Speed: public plazun
{
private:
	int speed;
public:
	Speed();
	
};
class Length : public plazun
{
private :
	float length;
public:
	Length();
};
class gaduka: public Length, public Speed
{
public : 
	void enddd();
private:
	int life;
};