#pragma once
class person
{
private:
	int age;
	char name[50];
	char city[50];
	char street[50];
	char job[50];
	int salary;
	char hobby[50];
public:
	void write_file( person& obj);
	void read_file(person* obj, int n);
	void print_file(const person *obj, int n);
	int work_life( person& obj);
};

