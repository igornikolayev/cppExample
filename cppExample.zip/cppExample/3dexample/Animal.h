#pragma once
class Dog;
class Animal
{
private:
	int age;
	char* type;
	char* name;
	char* color;
	int  weight;
	friend void setData(char *, int, Animal&);
	friend void getData(Animal&);
	friend Dog;

public:
	void write_file(Animal& obj);
	void read_file(Animal* obj, int n);
	void print_file(const Animal *obj, int n);
	Animal(const Animal &obj);
	Animal();
	~Animal();
	void setData(char*, int);
	void getData();
};
class Dog
{
public:
	void getChangeData(Animal);

};



