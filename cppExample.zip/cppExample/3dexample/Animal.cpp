#include "Animal.h"
#include "stdafx.h"
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
using namespace std;

void setData(char *n, int w, Animal& object)
{
	strcpy(object.name, n);
	object.weight = w;
}


void getData(Animal& object)
{
	cout << object.name << "\t: " << object.weight << " ��" << endl;
}
void Animal::setData(char *n, int w)//���������� set-����� ������
{
	strcpy(name, n);
	weight = w;
}
void Dog::getChangeData(Animal obj)
{
	cout << obj.name;
}
void Animal::getData()
{
	cout << name << "\t: " << weight << " ��" << endl;
}
Animal::Animal() : type(new char[20]), name(new char[20]) ,color(new char[20])
{
	cout << "��'� :";
	cin >> name;
	cout << "������ :";
	cin >> type;
	cout << "����� :";
	cin >> color;
	cout << "�� :";
	cin >> age;
	cout << "���� :";
	cin >> weight;
}
Animal::Animal(const Animal &obj)
	{
		type = new char[strlen(obj.type) + 1];
		strcpy(type, obj.type);
		name = new char[strlen(obj.name) + 1];
		strcpy(name, obj.name);
		color = new char[strlen(obj.color) + 1];
		strcpy(color, obj.color);
		age = obj.age;
		weight = obj.weight;
	}


Animal::~Animal()
{
	
	cout << endl << "��� ��������� ����������";
}

void Animal::write_file(Animal& obj)
{
	ofstream fout("i.dat", ios::app);
	fout << obj.name << endl;
	fout << obj.type << endl;
	fout << obj.age << endl;
	fout << obj.weight << endl;
	fout << obj.color << endl;
}
void Animal::read_file(Animal *obj, int n)
{
	ifstream fout("i.dat");
	for (int i = 0; i < n; i++)
	{
		fout >> obj[i].name;
		fout >> obj[i].type;
		fout >> obj[i].age;
		fout >> obj[i].weight;
		fout >> obj[i].color;
	}
}
void Animal::print_file(const Animal *obj, int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << "i�'� " << obj[i].name << "  ������ " << obj[i].type << endl << endl;
	}
}
